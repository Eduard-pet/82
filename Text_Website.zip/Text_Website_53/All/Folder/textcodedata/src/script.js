const loginPage = `
<div class="container">
    <h2>Login</h2>
    <form id="loginForm">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="passcode">Passcode:</label>
        <input type="password" id="passcode" name="passcode" required>
        <button type="submit">Login</button>
    </form>
    <a href="#" id="resetLink">Forgot Passcode?</a>
    <a href="#" id="signupLink">Sign Up</a>
</div>`;

const signupPage = `
<div class="container">
    <h2>Sign Up</h2>
    <form id="signupForm">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="passcode">Passcode:</label>
        <input type="password" id="passcode" name="passcode" required>
        <button type="submit">Sign Up</button>
    </form>
    <a href="#" id="loginLink">Back to Login</a>
</div>`;

const resetPasscodePage = `
<div class="container">
    <h2>Reset Passcode</h2>
    <form id="resetPasscodeForm">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Reset Passcode</button>
    </form>
    <p id="message"></p>
</div>`;

const newPasscodePage = `
<div class="container">
    <h2>Set New Passcode</h2>
    <form id="newPasscodeForm">
        <label for="newPasscode">New Passcode:</label>
        <input type="password" id="newPasscode" name="newPasscode" required>
        <label for="confirmPasscode">Confirm New Passcode:</label>
        <input type="password" id="confirmPasscode" name="confirmPasscode" required>
        <button type="submit">Submit</button>
    </form>
    <p id="message"></p>
</div>`;

document.getElementById('app').innerHTML = loginPage;

document.getElementById('app').addEventListener('click', function(event) {
    if (event.target && event.target.id === 'resetLink') {
        event.preventDefault();
        document.getElementById('app').innerHTML = resetPasscodePage;
    } else if (event.target && event.target.id === 'signupLink') {
        event.preventDefault();
        document.getElementById('app').innerHTML = signupPage;
    } else if (event.target && event.target.id === 'loginLink') {
        event.preventDefault();
        document.getElementById('app').innerHTML = loginPage;
    }
});

document.getElementById('app').addEventListener('submit', function(event) {
    event.preventDefault();
    if (event.target.id === 'loginForm') {
        const email = event.target.email.value;
        const passcode = event.target.passcode.value;
        const storedPasscode = localStorage.getItem(email);
        if (storedPasscode && storedPasscode === passcode) {
            alert('Login successful');
        } else {
            alert('Invalid email or passcode');
        }
    } else if (event.target.id === 'signupForm') {
        const email = event.target.email.value;
        const passcode = event.target.passcode.value;
        if (localStorage.getItem(email)) {
            alert('Email already exists');
        } else {
            localStorage.setItem(email, passcode);
            alert('Signup successful');
            document.getElementById('app').innerHTML = loginPage;
        }
    } else if (event.target.id === 'resetPasscodeForm') {
        const email = event.target.email.value;
        if (localStorage.getItem(email)) {
            localStorage.setItem('resetEmail', email);
            alert('A reset link has been sent to ' + email + '.');
            document.getElementById('app').innerHTML = newPasscodePage;
        } else {
            alert('Email not found');
        }
    } else if (event.target.id === 'newPasscodeForm') {
        const newPasscode = event.target.newPasscode.value;
        const confirmPasscode = event.target.confirmPasscode.value;
        const email = localStorage.getItem('resetEmail');
        if (newPasscode === confirmPasscode && email) {
            localStorage.setItem(email, newPasscode);
            localStorage.removeItem('resetEmail');
            alert('Your passcode has been reset successfully.');
            document.getElementById('app').innerHTML = loginPage;
        } else {
            alert('Passcodes do not match or email not found. Please try again.');
        }
    }
});
