# Textcodedata

A Pen created on CodePen.io. Original URL: [https://codepen.io/Eduardandreipetriceanu18/pen/rNEywyX](https://codepen.io/Eduardandreipetriceanu18/pen/rNEywyX).

